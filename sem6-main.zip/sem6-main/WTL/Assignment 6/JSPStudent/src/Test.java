public class Test{  
public static void main(String args[]){  
Student e=new Student();//object is created  
e.setName("Afnan");//setting value to the object  
System.out.println(e.getName());  
}}  