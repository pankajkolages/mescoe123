package com.demo.ejb.banking.exception;

public class InsufficientBalanceException extends Exception {
	private static final long serialVersionUID = -2884740553592516702L;

}
