package com.demo.ejb.banking.exception;

public class AccountExistsException extends Exception {
	private static final long serialVersionUID = 4737933148525051503L;

}
