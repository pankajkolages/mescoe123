

<!DOCTYPE html>
<html>
<head>
<title>
welcome
</title>
</head>
<body style="background-color:#9d869e;text-align:center">
<h1 style="text-align:center">Welcome user</h1>
<label>delete account? <a href="delete.php">click here</a></label><br>
<label>getdata? <a href="getdata.php">click here</a></label><br>
<label><a href="login.php">Home</a></label>
</body>
</html>
