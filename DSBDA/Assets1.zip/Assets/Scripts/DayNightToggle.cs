using UnityEngine;

public class DayNightToggle : MonoBehaviour
{
    public Light sunLight; // Assign your directional light here
    public Material daySkybox;
    public Material nightSkybox;

    private bool isDay = true;

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Left mouse click
        {
            if (isDay)
            {
                // Switch to Night
                RenderSettings.skybox = nightSkybox;
                sunLight.intensity = 0.2f;
                sunLight.color = Color.blue;
            }
            else
            {
                // Switch to Day
                RenderSettings.skybox = daySkybox;
                sunLight.intensity = 1.0f;
                sunLight.color = Color.white;
            }

            isDay = !isDay;
        }
    }
}
